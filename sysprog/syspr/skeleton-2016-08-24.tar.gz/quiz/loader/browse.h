/**
 * \file	loader/browse.h
 * \author	Stefan Gast
 *
 * \brief	Deklaration des Verzeichnislisters
 */

#ifndef BROWSE_H
#define BROWSE_H

void browse(const char *directory_name);

#endif
