/*
 * Systemprogrammierung
 * Multiplayer-Quiz
 *
 * Server
 * 
 * login.c: Implementierung des Logins
 */

#include "common/util.h"
#include "login.h"
#include "rfc.h"
#include "clientthread.h"
#include "user.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h> 
#include <errno.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
/*
* Login-Thread ließt Login-Anfrage von Clients ein
* Spielerdaten Struktur getClientData() setClient() user.c
* LOK rfc.c, LOK senden user.c
* erzeugt Clientthreads clientthread.c
*/

void *loginThread(void* parameter){
  
    int s_sockfd = *(int*)parameter;
    
    //Spielerdaten  
    clientdata client_data[4];
    
    //Client-Struktur in user.c 
    client_data[4] = getClientData();
    
    //Mutex - Schutz Kritischer Abschnitt
    pthread_mutex_t lockData = PTHREAD_MUTEX_INITIALIZER;
   
    int c_sockfd;
    socklen_t clientlen;
    struct sockaddr_in client_addr;
    char clientMessage[1000];
    int n;
    pthread_t client; 
    client_data[0].players = 4; //Struktur User	
  	
		memset(clientMessage, '\0', sizeof(clientMessage));     
		while(1) {   
		    clientlen = sizeof(client_addr); 
        c_sockfd = accept(s_sockfd, (struct sockaddr *) &client_addr, &clientlen);
        
        if (c_sockfd < 0){
			      errorPrint("Fehler: Socket akzeptieren");
			      return 0;
    		}
    		
    		//5.Client abweisen
     		if(client_data[0].players == 0){
			     errorPrint("Spieler abweisen, es sind bereits 4 Spieler angemeldet.");
			     close(c_sockfd);
			     continue;
		    }

    		//Vom Socket lesen
    		n = read(c_sockfd,clientMessage,sizeof(clientMessage));
    		
    		if (n< 0) {
     	     errorPrint("Fehler beim Lesen vom Socket");
     	     return 0;
     	  }	
     	  //Mutex - Kritischer Abschnitt
          pthread_mutex_lock(&lockData); 
        
        //Eingehende Nachricht LRQ
        if(clientMessage[0] == 1) { 
     	  //setClient() Clientdaten in Struktur setzen
    		 setClient(clientMessage, c_sockfd, client_data); //LOK-Type 2 in user.c  
          
          //5.Client abweisen 	                  
	        client_data[0].players--;
	        
	        pthread_mutex_unlock(&lockData);
     	  
     	    //Clientthread erzeugen
          if((pthread_create (&client, NULL, clientThread, (void*)&c_sockfd)) < 0){
            errorPrint("Fehler beim client-Thread erzeugen");
          }
          infoPrint("client-Thread erfolgreich");
     	  }
   }  

   close(c_sockfd);
   close(s_sockfd);
   infoPrint("Login-Thread beendet.");
   pthread_exit(NULL);
}



