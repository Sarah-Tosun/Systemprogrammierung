/*
 * Systemprogrammierung
 * Multiplayer-Quiz
 *
 * Server
 *
 * rfc.h: Definitionen für das Netzwerkprotokoll gemäß dem RFC
 */

#ifndef RFC_H
#define RFC_H
#define MAX_NAME 32

#include "common/question.h"
#include "user.h"

#pragma pack(push, 1)
typedef struct Header{
  uint8_t type;
  uint16_t length;
}header; 

// Type 1
typedef struct LoginRequest{
  header header; 
  uint8_t rfcVersion;
  char name[MAX_NAME];
}LRQ; 

// Type 2

typedef struct LoginResponseOk{
  header header; 
  uint8_t rfcVersion;
  uint8_t maxPlayers;
  uint8_t clientID;
}LOK;

// Type 3
typedef struct CatalogRequest{
  header header;
}CRQ;

// Type 4
typedef struct CatalogResponse{
  header header; 
  char fileName[60]; //nicht 0 terminiert oder leer
}CRE; 

// Type 5
typedef struct CatalogChange{
  header header; 
  char fileName[60]; //nicht 0 terminiert oder leer
}CCH;

//Spieler
typedef struct{
	char name[MAX_NAME];
	uint32_t score;
	uint8_t clientID;
}player;

// Type 6
typedef struct LST{
  header header; 
  player player[4];
}LST;

// Type 7
typedef struct StartGame{
  header header; 
  char fileName[60]; //nicht 0 terminiert oder leer
}STG;

// Type 8
typedef struct QuestionRequest{
  header header;
}QRQ;

// Type 9
union Question{
  header header;   // 769 oder 0
  struct Data{
      char questionText[256]; //0-terminiert
      char answerText1[128];
      char answerText2[128];
      char answerText3[128];
      char answerText4[128];
      uint8_t timeLimit;
  }data;
}QUE;

// Type 10
typedef struct QuestionAnswered{
  header header; 
  uint8_t bitmask; //ersten 4 Stellen 0 (Werte 1-16 niedrigste Bit Frage 1 gewählt)
}QAN;

// Type 11
typedef struct QuestionResult{
  header header; 
  uint8_t bitmask; //aber bei bitmask höchste bit gesetzt bei Zeitlimitüberschreitung, sonst analog
}QRE; 
 
// Type 12
typedef struct GameOver{
  header header; 
  uint8_t rank; // rank => 4 und rank <= 0 (Rang der Spieler)
}GOV;

// Type 13
typedef struct ErrorWarning{
  header header; 
  uint8_t subtype; // 0 Warnung 1 Client muss sich beenden
  char errorMessage[200];
}Err;

#pragma pack(pop)
  
LOK getLOK(int id);
CRE getCRE(char catalogs[]);
CCH getCCH(int id);
LST getLST(int clientNo);


void sendLOK(int c_sockfd, int clientNo);
void sendCRE(int c_sockfd);
void sendCCH(int c_sockfd);
void sendLST(int c_sockfd, int clientNo);

player getPlayer();

#endif
