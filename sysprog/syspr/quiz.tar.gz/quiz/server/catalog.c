/*
 * Systemprogrammierung
 * Multiplayer-Quiz
 *
 * Server
 * 
 * catalog.c: Implementierung der Fragekatalog-Behandlung und Loader-Steuerung
 */

#include "common/server_loader_protocol.h"
#include "catalog.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>


int stdoutPipe[2];
int stdinPipe[2];

int startLoader(char catpath[]){

  if(pipe(stdinPipe) == -1 || pipe(stdoutPipe) == -1){
    perror("Pipe konnte nicht erzeugt werden");
    return 3;
  }
  
  pid_t pid = fork();
  if(pid < 0){
    perror("forking nicht erfolgreich, kein Kindprozess");
    return 1;
  }
  else if(pid == 0){ //Kindprozess
  
    if(dup2(stdinPipe[0], STDIN_FILENO) == -1){
      perror("dup2(stdinPipe[0], STDIN_FILENO)"); //Kindseite lesen
      return 4;
    }
    /* Umleitung der Standardausgabe */
    if(dup2(stdoutPipe[1], STDOUT_FILENO) == -1){
      perror("dup2(stdoutPipe[1], STDOUT_FILENO"); //Kindseite schreiben
      return 5;
    }
    close(stdinPipe[0]); close(stdinPipe[1]); 
    close(stdoutPipe[0]); close(stdoutPipe[1]); 
    
    execl("loader", "loader", ".",catpath, NULL);
    perror("execl");
    return 2;
    
  }
  else{//Elternprozess
  	close(stdinPipe[0]); 
    close(stdoutPipe[1]);
  }
  perror("Der Loader wurde erfolgreich gestartet.");
  return 0;
}

int listCat(){
  char cat1[] = {"simple.cat"};
  char cat2[] = {"Systemprogrammierung.cat"};
  
  for(int i = 0; i < sizeof(cat1); i++){
    cn.catalog[i] = cat1[i];
  }
  catalogs.catNo = 1;
  
  write(stdinPipe[1], cat1, sizeof(cat2));
  write(stdinPipe[1], cat1, sizeof(cat2));
  //read(stdoutPipe[0],array, sizeof(array)); 
  return 0;
}
