/*
 * Systemprogrammierung
 * Multiplayer-Quiz
 *
 * Server
 * 
 * catalog.h: Header für die Katalogbehandlung und Loader-Steuerung
 */

#ifndef CATALOG_H
#define CATALOG_H

int startLoader(char catpath[]);
int listCat();

typedef struct{
	char catalog[60];
}catName;
catName cn;

typedef struct{
	catName catName[5];
	int catNo;	
	char currentCat[100];
}catalog;

catalog catalogs;

#endif
