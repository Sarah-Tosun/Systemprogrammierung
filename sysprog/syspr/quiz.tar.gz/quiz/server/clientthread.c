/*
 * Systemprogrammierung
 * Multiplayer-Quiz
 *
 * Server
 * 
 * clientthread.c: Implementierung des Client-Threads
 */

#include "clientthread.h"
#include "login.h"
#include "rfc.h"
#include "common/util.h"
#include "catalog.h"
#include "user.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <errno.h>
#include <unistd.h>

/*
* Eingehende Nachrichten auswerten
* Nachrichtenaufbau, Versand rfc.c
* Spielerdaten in user.c
*/

void *clientThread(void* parameter){

  int c_sockfd = *(int*)parameter;
  //pthread_mutex_t mutexScore = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_t mutexData = PTHREAD_MUTEX_INITIALIZER;
  
  //Spielerdaten  
  clientdata client_data[4];
    
  while(1){
    char clientMessage[200];
    int n = 0;
    n = read(c_sockfd,clientMessage,sizeof(clientMessage));
    
    if (n < 0) {
      infoPrint("Fehler beim Lesen vom Socket_Clientthread");
     	return 0;
     	pthread_exit(NULL);
    } 
    
    switch(clientMessage[0]){ 		  
      case 3: sendCRE(c_sockfd); 
              infoPrint("CRE"); //Case 3 CRS dann sende CRE   
    		    break;   		    
    	case 5: infoPrint("CCH");
    	       //MUTEX
    	       // Spielleiter wählt Katalog
    	       sendCCH(c_sockfd);
    	       // Auswahl an alle Clients -  Solange i < ClientNo, client_data[i].csockfd
    		    break; 
      case 7: infoPrint("STG");
    	       //sendSTG();
    	       // Start Game
    		    break; 
      case 9: infoPrint("QUE");
             // Frage senden
    	       //sendQUE();
    		    break; 
      case 11: infoPrint("QRE");
             //Frageergebnis Punktestand ändert sich -- Score
             //MUTEX Punktestand ändert sich 
             //pthread_mutex_lock(&mutexScore);
             //pthread_mutex_unlock(&mutexScore);
    	       //sendQRE();
    	       //Eintritt Semaphor Score -
    	       //sem_t scoreSemaphore;
             //scoreSemaphore = getSemaphore;
    	       //sem_post(&scoreSemaphore);

    		    break;      		
    } 
    //Client-Struktur in user.c 
    pthread_mutex_lock(&mutexData);
    int no = getClientNo(client_data);
    client_data[4] = getClientData(); ////????? Warum keine Werte in Struktur
    infoPrint("no %d", no); /// ???
    pthread_mutex_unlock(&mutexData);
    
    //Spielerliste versenden
    // LST versenden bei An-/Abmelden, Spielstart, QRE wenn Score "akt" anders Score "alt" 
      sendLST(c_sockfd, client_data[no].clientID);
      infoPrint("LST");
      infoPrint("Client-ID %d", client_data[no].clientID); //2.Spieler ID müsste 1!  ????
    
    //Wer ist Spielleiter
    if(isGameLeader(c_sockfd)){   
    //Wird das Spiel verlassen hat n den Wert 0
    infoPrint("clientthread n wert %d", n);     
      if (n == 0) {
        infoPrint("Bist du Spielleiter? %d", c_sockfd);
					infoPrint("Spielleiter hat das Spiel verlassen");
			   }
			   pthread_exit(NULL);   
    }
     
   //MUTEX Client auf Spielende warten lassen
   
   //Keine Fragen mehr vorhanden,alle sind fertig -- GAME OVER - Nachricht Endstand Score
   }
}





