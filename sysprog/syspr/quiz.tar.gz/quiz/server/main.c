/*
 * Systemprogrammierung
 * Multiplayer-Quiz
 *
 * Server
 * 
 * main.c: Hauptprogramm des Servers
 */

#include "common/util.h"
#include "login.h"
#include "score.h"
#include "catalog.h"
#include "user.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h> 
#include <netinet/in.h> 
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
/*
* Socket erstellen, bind(), listen() 
* Loader starten:  startLoader(); in catalog.c
* LoginThread erzeugen  login.c
* ScoreThread erzeugen  score.c
*
*/

int main(int argc, char **argv)
{
    setProgName(argv[0]); 
    infoPrint("Server Gruppe 18");
	  
    int opt;
    int port = 1234;; //Standardport
    struct sockaddr_in server_addr;
    char catpath[] = {""}; //"../Fragekataloge"
    
    //eingegebener Port -p übernehmen
    if((opt = getopt(argc, argv, "p")) != -1){ 
      port = atoi(optarg);
    }
    
    //Socket
    int s_sockfd = socket(AF_INET, SOCK_STREAM, 0);
    
    if(s_sockfd < 0){
       errorPrint("Fehler: Socket konnte nicht erstellt werden");
       return 0;
    }
    
    bzero((char *) &server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;            //IPv4
    server_addr.sin_addr.s_addr = INADDR_ANY;    //Adressen
    server_addr.sin_port = htons(port);            //Port

    if (bind(s_sockfd, (struct sockaddr *) &server_addr, sizeof(server_addr)) < 0) {
        errorPrint("Fehler beim Binden an die Adresse");
        exit(0);
    }
    
    //4 Clients
  	if(listen(s_sockfd,4)){
  	  errnoPrint("Fehler beim Warten auf Clients");
  	  return 0;
  	} 
    
    //LoginThread erzeugen, server-socket übergeben
    if((pthread_create (&login, NULL, (void *)loginThread, (void*)&s_sockfd)) != 0){
        errorPrint("Fehler beim Login-Thread erzeugen");
    }
    infoPrint("Login-Thread erfolgreich");
    
    //Loader aufrufen in catalog.c
    startLoader(catpath);
    
    //ScoreThread erzeugen
    if((pthread_create (&score, NULL, (void *)scoreThread, NULL)) != 0){
      errorPrint("Fehler beim Score-Thread erzeugen");
    }
    infoPrint("Score-Thread erfolgreich");
    
    pthread_join(login, NULL); 
    pthread_join(score, NULL); 
    
return 0;
}
