/*
 * Systemprogrammierung
 * Multiplayer-Quiz
 *
 * Server
 * 
 * score.h: Implementierung des Score-Agents
 */

#include "score.h"
#include "login.h"
#include "catalog.h"
#include "rfc.h"
#include "common/util.h"
#include "user.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void *scoreThread(void* parameter){
  sem_t scoreSemaphore;
  //scoreSemaphore = getSemaphore();
  
  sem_wait(&scoreSemaphore);
  int players;
  clientdata client_data[4];
  client_data[4] = getClientData();
  
	while(1){
		players = getClientNo(client_data);
		
	  LST lst;
	  lst = getLST(players);
	   
	  for(int i=0;client_data[i].clientID != 0 && i < 4;i++){
		  write(client_data[i].clientID, &lst, ((1+players)*37)+3);
		  infoPrint("%d", client_data[i].clientID);
	  }	
  }
}

sem_t getSemaphor(){
    sem_t scoreSemaphore;
    return scoreSemaphore;
}