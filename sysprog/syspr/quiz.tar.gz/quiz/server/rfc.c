/*
 * Systemprogrammierung
 * Multiplayer-Quiz
 *
 * Server
 *
 * rfc.c: Implementierung der Funktionen zum Senden und Empfangen von
 * Datenpaketen gemäß dem RFC
 */

#include "rfc.h"
#include "user.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <netinet/in.h> 
#include <errno.h>
#include <unistd.h>

LOK getLOK(int id){
  LOK lok;
  lok.header.type = 2;
  lok.header.length = htons(3);
  lok.rfcVersion = 9;
  lok.maxPlayers = 4;
  lok.clientID = id;
  return lok;
}
CRE getCRE(char catalogs[]){
  CRE cre;
  cre.header.type = 4;
  cre.header.length = htons(strlen(cre.fileName)+3);
  strcpy(cre.fileName, catalogs);
  return cre;
}

CCH getCCH(int id){
  CCH cch;
  cch.header.type = 5;
  cch.header.length = htons(3);
  return cch;
}

LST getLST(int clientNo){ 
  player player[4];
  player[4] = getPlayer();
  
	LST lst; 
	lst.header.type = 6;
	lst.header.length = htons((clientNo)*37);
	for(int i=0;i<4;i++){
		memset(lst.player[i].name, '\0' , sizeof(lst.player[i].name));
	}
	
	for(int i=0;i<4;i++){
		strcpy(lst.player[i].name, player[i].name);
		lst.player[i].score = htonl(player[i].score);
		lst.player[i].clientID = player[i].clientID;
	}
	return lst;
}


//Senden

void sendLOK(int c_sockfd, int clientNo){
	LOK lok;	
	lok = getLOK(clientNo);
  write(c_sockfd, &lok, sizeof(lok));
}

void sendCRE(int c_sockfd){
    for(int i=0;i < 2;i++){ //catalogs.catNo
		  CRE cre;
		  cre = getCRE("simple"); //(catalogs.catName[i].catalog);
      write(c_sockfd, &cre, strlen(cre.fileName)+3);
      infoPrint("NAmeCRE %s", cre.fileName);
    }
    
	  // leerer Katalog, letzter
	  CRE cre;
	  cre = getCRE("");
	  write(c_sockfd, &cre, strlen(cre.fileName));
    infoPrint("sendCRE in rfc.c");
    
}

void sendLST(int c_sockfd, int clientNo){
    LST lst;
    lst = getLST(clientNo);
    write(c_sockfd, &lst, sizeof(lst));
}

void sendCCH(int c_sockfd){
  CCH cch;
  cch = getCCH(c_sockfd);
  clientdata clientdata[4];
  clientdata[4] = getClientData();  
  
    for(int i = 0; clientdata[i].name[0] != '\0'; i++){
      //an alle außer Spielleiter
      write(c_sockfd, &cch, sizeof(cch));
	  }
}




