/*
 * Systemprogrammierung
 * Multiplayer-Quiz
 *
 * Server
 * 
 * user.h: Header für die User-Verwaltung
 */

#ifndef USER_H
#define USER_H

#include "rfc.h"

typedef struct{
	char name[MAX_NAME];
	uint32_t score;
	uint8_t clientID;
	int players;
	int cSockfd;
}clientdata;

int setClient(char clientMessage[], int c_sockfd, clientdata client_data[]);
clientdata getClientData();
void setPlayer(char clientname[], int clientNo);
int getClientNo(clientdata client_data[]);
int isGameLeader(int c_sockfd);

#endif
