/*
 * Systemprogrammierung
 * Multiplayer-Quiz
 *
 * Server
 * 
 * user.c: Implementierung der User-Verwaltung
 */

#include "user.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h> 
#include <errno.h>
#include <unistd.h>

/*
* setClient() Spielerdaten anlegen, und LOK versenden
* setPlayer() Spielerliste anlegen
* getClientNo() Spieleranzahl ermitteln
* getClientData() ClientStruktur zurückgeben
* getPlayer() Spieler (Spielerliste)
* isGameLeader() Spielleiter ermitteln
*/

int setClient(char clientMessage[], int c_sockfd, clientdata client_data[]){

  int clientNo = getClientNo(client_data);
  
  char clientname[32];
  int a = 0;
  int j = 0;
  for(int i = 4; clientMessage[i] != '\0';i++){   //int 4 = 32bit
    clientname[j] = clientMessage[i];
    j++;  
    if(a < clientNo){
      a++;
    }
  } 
  //ClientStruktur gefüllt
  strcpy(client_data[clientNo].name, clientname);
  infoPrint("%s",client_data[clientNo].name); //Name(client1) ???? 
  client_data[clientNo].score = 0;
  client_data[clientNo].clientID = clientNo;
  client_data[clientNo].cSockfd = c_sockfd;
  
  infoPrint("StruktID %d", client_data[clientNo].clientID);
  infoPrint("No %d", clientNo);  
  
   //LOK 
   sendLOK(c_sockfd, clientNo);
   infoPrint("LOK");
   
   setPlayer(clientname, clientNo); 

  return 1; 
}

void setPlayer(char clientname[], int clientNo){
  player player[4];
  //PlayerStruktur gefüllt
  strcpy(player[clientNo].name, clientname);
  player[clientNo].score = 0;
  player[clientNo].clientID = clientNo;
}

player getPlayer(){
  player player[4];
  return player[4];
}

//Clientanzahl ermitteln
int getClientNo(clientdata client_data[]){
	int clientCount = 0;
	for(int i = 0; i < 4; i++){
		if(client_data[i].name[0] != '\0'){
			clientCount++;
		}
	}
	return clientCount;
}

//StrukturArrayVariable zurückgeben
clientdata getClientData(){
  clientdata client_data[4];
  infoPrint("DatenStruktur in user.c %d", client_data[0].clientID);
  return client_data[4];
}

//Spielleiter ermittelt
int isGameLeader(int c_sockfd){
  
  clientdata client_data[4];
  client_data[4] = getClientData();
  
  for(int i=0;i<4;i++){
		  if(client_data[i].cSockfd == c_sockfd){
		    if(client_data[i].clientID == 0){
				return 1;
			}else{
				return 0;
			}
		}
	}return 0;
}



   
